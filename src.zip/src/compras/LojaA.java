package compras;

public abstract class LojaA {
    abstract void adicionarProduto();

    abstract void comprarProduto();

    abstract void atualizarTotal(double total);
}
