package compras;

public class Exception extends RuntimeException {

    public Exception(String msg) {
        super(msg);


    }
}
